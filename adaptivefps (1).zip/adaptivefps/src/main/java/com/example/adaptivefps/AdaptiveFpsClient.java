package com.example.adaptivefps;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AdaptiveFpsClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("AdaptiveFPS");
    public static Config CONFIG;
    public static final Controller CONTROLLER = new Controller();

    @Override
    public void onInitializeClient() {
        CONFIG = Config.load();
        ClientTickEvents.END_CLIENT_TICK.register(CONTROLLER::tick);
        // Вернуть исходные настройки при выходе, чтобы они не сохранились сниженными
        ClientLifecycleEvents.CLIENT_STOPPING.register(CONTROLLER::restore);
    }
}
