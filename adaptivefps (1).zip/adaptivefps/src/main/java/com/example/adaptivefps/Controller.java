package com.example.adaptivefps;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.option.GameOptionsScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;

/**
 * Каждую секунду замеряет FPS и переключает "уровень экономии" 0..MAX_LEVEL.
 * Уровни только УМЕНЬШАЮТ исходные настройки игрока (min с базой) и ничего не пишут на диск.
 */
public class Controller {
    public static final int MAX_LEVEL = 5;
    private static final int COOLDOWN_TICKS = 20 * 8;   // не чаще раза в 8 с (смена дистанции перезагружает чанки)
    private static final int RECOVER_TICKS = 20 * 20;   // запас по FPS должен держаться 20 с, чтобы повысить качество

    // Пресеты: {дистанция прорисовки (кап), масштаб сущностей x100, particles(0=ALL,1=DEC,2=MIN), тени(1=вкл), облака(1=вкл), biome blend}
    private static final int[][] PRESETS = {
        {99, 500, 0, 1, 1, 99},
        {12, 100, 0, 1, 1, 99},
        {10,  75, 1, 0, 1, 3},
        { 8,  60, 1, 0, 0, 1},
        { 6,  50, 2, 0, 0, 0},
        { 4,  40, 2, 0, 0, 0},
    };

    private int level = 0;
    private int tickCounter = 0;
    private int sinceChange = COOLDOWN_TICKS;
    private int goodTicks = 0;
    private double avg = 0;

    // Исходные настройки игрока
    private boolean captured = false;
    private int baseView, baseBlend, baseMaxFps;
    private double baseEntityScale;
    private ParticlesMode baseParticles;
    private CloudRenderMode baseClouds;
    private boolean baseShadows;
    private boolean throttledFps = false;

    public int level() { return level; }
    public double avgFps() { return avg; }

    public void tick(MinecraftClient client) {
        if (client.options == null) return;
        Config cfg = AdaptiveFpsClient.CONFIG;
        if (!cfg.enabled) return;

        // В экранах настроек возвращаем исходные значения, чтобы игра не записала сниженные в options.txt
        if (client.currentScreen instanceof OptionsScreen || client.currentScreen instanceof GameOptionsScreen) {
            if (captured) restore(client);
            return;
        }

        handleFpsCaps(client, cfg);

        if (client.world == null) return;
        if (++tickCounter < 20) return;
        tickCounter = 0;
        sinceChange += 20;

        int fps = client.getCurrentFps();
        avg = avg == 0 ? fps : avg * 0.7 + fps * 0.3;

        // Не реагируем, пока игра свёрнута/в меню — FPS там искусственно занижен или завышен
        if (!client.isWindowFocused() || client.currentScreen != null) return;

        if (avg < cfg.targetFps * 0.9 && level < MAX_LEVEL && sinceChange >= COOLDOWN_TICKS) {
            setLevel(client, level + 1);
            goodTicks = 0;
        } else if (avg > cfg.targetFps * 1.3 && level > 0) {
            goodTicks += 20;
            if (goodTicks >= RECOVER_TICKS && sinceChange >= COOLDOWN_TICKS) {
                setLevel(client, level - 1);
                goodTicks = 0;
            }
        } else {
            goodTicks = 0;
        }
    }

    private void capture(GameOptions o) {
        if (captured) return;
        baseView = o.getViewDistance().getValue();
        baseEntityScale = o.getEntityDistanceScaling().getValue();
        baseParticles = o.getParticles().getValue();
        baseClouds = o.getCloudRenderMode().getValue();
        baseShadows = o.getEntityShadows().getValue();
        baseBlend = o.getBiomeBlendRadius().getValue();
        captured = true;
    }

    private void setLevel(MinecraftClient client, int newLevel) {
        GameOptions o = client.options;
        capture(o);
        level = newLevel;
        sinceChange = 0;
        int[] p = PRESETS[level];

        o.getViewDistance().setValue(Math.max(AdaptiveFpsClient.CONFIG.minViewDistance, Math.min(baseView, p[0])));
        o.getEntityDistanceScaling().setValue(Math.min(baseEntityScale, p[1] / 100.0));
        o.getParticles().setValue(ParticlesMode.values()[Math.max(baseParticles.ordinal(), p[2])]);
        o.getEntityShadows().setValue(baseShadows && p[3] == 1);
        o.getCloudRenderMode().setValue(p[4] == 1 ? baseClouds : CloudRenderMode.OFF);
        o.getBiomeBlendRadius().setValue(Math.min(baseBlend, p[5]));
    }

    /** Лимит FPS в фоне и в меню. */
    private void handleFpsCaps(MinecraftClient client, Config cfg) {
        GameOptions o = client.options;
        int cap = 0;
        if (!client.isWindowFocused()) cap = cfg.backgroundFps;
        else if (client.currentScreen != null && cfg.menuFps > 0) cap = cfg.menuFps;

        if (cap > 0) {
            if (!throttledFps) { baseMaxFps = o.getMaxFps().getValue(); throttledFps = true; }
            if (o.getMaxFps().getValue() != cap) o.getMaxFps().setValue(cap);
        } else if (throttledFps) {
            o.getMaxFps().setValue(baseMaxFps);
            throttledFps = false;
        }
    }

    /** Вернуть настройки игрока (при /adaptivefps off). */
    public void restore(MinecraftClient client) {
        if (client.options == null) return;
        GameOptions o = client.options;
        if (captured) {
            o.getViewDistance().setValue(baseView);
            o.getEntityDistanceScaling().setValue(baseEntityScale);
            o.getParticles().setValue(baseParticles);
            o.getEntityShadows().setValue(baseShadows);
            o.getCloudRenderMode().setValue(baseClouds);
            o.getBiomeBlendRadius().setValue(baseBlend);
            captured = false;
        }
        if (throttledFps) { o.getMaxFps().setValue(baseMaxFps); throttledFps = false; }
        level = 0; sinceChange = COOLDOWN_TICKS; goodTicks = 0;
    }
}
