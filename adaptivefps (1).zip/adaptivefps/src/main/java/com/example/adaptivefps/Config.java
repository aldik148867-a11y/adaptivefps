package com.example.adaptivefps;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("adaptivefps.json");

    public boolean enabled = true;
    /** Желаемый FPS. Мод опускает графику, если средний FPS ниже ~90% цели. */
    public int targetFps = 120;
    /** Минимальная дистанция прорисовки, ниже которой мод не опускается. */
    public int minViewDistance = 4;
    /** Ограничение FPS, когда окно не в фокусе (экономит GPU/батарею). */
    public int backgroundFps = 15;
    /** Ограничение FPS в меню/на паузе. 0 = не ограничивать. */
    public int menuFps = 60;

    public static Config load() {
        try {
            if (Files.exists(PATH)) {
                Config c = GSON.fromJson(Files.readString(PATH), Config.class);
                if (c != null) return c;
            }
        } catch (Exception e) {
            AdaptiveFpsClient.LOGGER.warn("Не удалось прочитать конфиг, использую стандартный", e);
        }
        Config c = new Config();
        c.save();
        return c;
    }

    public void save() {
        try {
            Files.writeString(PATH, GSON.toJson(this));
        } catch (IOException e) {
            AdaptiveFpsClient.LOGGER.warn("Не удалось сохранить конфиг", e);
        }
    }
}
